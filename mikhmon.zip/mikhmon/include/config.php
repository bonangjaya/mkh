<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');

$data['HotelCentral'] = array ('1'=>'HotelCentral!us-1.hostddns.us:8358','HotelCentral@|@admin','HotelCentral#|#rJKdp5+fmaSrmZ6Tpg==','HotelCentral%CentralHotel','HotelCentral^centralhotel.net','HotelCentral&Rp','HotelCentral*10','HotelCentral(1','HotelCentral)','HotelCentral=10','HotelCentral@!@enable');
$data['dapoercentral'] = array ('1'=>'dapoercentral!us-1.hostddns.us:8358','dapoercentral@|@admin','dapoercentral#|#mZWfoZ+Wmw==','dapoercentral%dapoercentral','dapoercentral^dapoercentral.net','dapoercentral&Rp','dapoercentral*10','dapoercentral(1','dapoercentral)','dapoercentral=10','dapoercentral@!@disable');
$data['egrehotspot'] = array ('1'=>'egrehotspot!192.168.1.2','egrehotspot@|@admin','egrehotspot#|#mZWfoZ9ksJWW','egrehotspot%egrehotspot','egrehotspot^egrehotspot.net','egrehotspot&Rp','egrehotspot*10','egrehotspot(1','egrehotspot)','egrehotspot=10','egrehotspot@!@enable');